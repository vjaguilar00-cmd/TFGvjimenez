# -*- coding: utf-8 -*-
"""
Created on Sat Aug  2 10:37:08 2025

@author: luisa
"""

import random
import math
import json
import matplotlib.pyplot as plt
import sys
import numpy as np



def ifnull(pos, val):
    l = len(sys.argv)
    if len(sys.argv) <= 1 or (sys.argv[pos] == None):
        return val
    return sys.argv[pos]

maxi=int(ifnull(1,20))

aleat=ifnull(2,42)
random.seed(aleat) #fijar semilla

model=ifnull(3,"MALP")

cap_cob=round(float(ifnull(4,0.01)),4)
print(cap_cob)

per=float(ifnull(5,0.1))


instancia=int(ifnull(6,1))


radius = 100
num_points = maxi

if model=="SCP":
    K=[]
    for i in range(maxi-1):
        K.append(i)
    p=maxi
    f = [1] * maxi
    ei= [1]*maxi
    b=[1]*maxi
    g=[]
    for i in range(maxi):
        g.append([0]*(maxi-1))

if model=="SCP_Backup":
    beta=0.6
    p=int(round(per*maxi))
    K=[]
    for i in range(p):
        K.append(i)
    f = [0] * maxi
    ei= [p]*maxi
    b=[0]*maxi
    tj=1
    g=[]
    gaux1=[-beta*tj]
    gaux2=[-(1-beta)*tj]
    gaux3=[0]*(p-2)
    gaux=gaux1+gaux2+gaux3
    for i in range(maxi):
        g.append(gaux)
        
        
if model=="MCLP":
    p=int(round(per*maxi))
    K=[]
    for i in range(p):
        K.append(i)
    f = [0] * maxi
    ei= [1]*maxi
    b=[0]*maxi
    g=[]
    gaux1=[-1]
    gaux2=[0]*(p-1)
    gaux=gaux1+gaux2
    for i in range(maxi):
        g.append(gaux)
        
        
if model=="PPAC":
    p=int(round(per*maxi))
    K=[]
    for i in range(p):
        K.append(i)
    f = [0] * maxi
    ei= [1]*maxi
    b=[0]*maxi
    g=[]
    T=[random.randint(-4, -1) for _ in range(maxi)]
    for i in range(maxi):
        g.append([T[i]]*p)
        
   
   
#Generación de puntos en el círculo de radio 100
points = []
for j in range(num_points):
    r = radius * math.sqrt(random.random()) #radio <=100
    theta = random.uniform(0, 2 * math.pi)  # Ángulo
    x = round(r * math.cos(theta),4)
    y = round(r * math.sin(theta),4)
    points.append([x,y])


distances = [[
    float(np.sqrt(sum((points[j][r] - points[i][r])**2 for r in range(2))))
    for i in range(maxi)]
    for j in range(maxi)]

    
rad=round(cap_cob * np.mean(distances),2)
print(rad)
cover=[]
for i in range(maxi):
    for j in range(maxi):
        if (distances[i][j]<rad):
            cover.append([i,j,1])


data={
      "model":model,
      "maxi":maxi,
      "p":p,
      "rad":rad,
      "points":points,
      "cover":cover,
      "K":K,
      "f":f,
      "e":ei,
      "b":b,
      "g":g,
      "cap_cob":cap_cob,
      "per":per
      }

# Export to JSON
with open("data_malp/data_"+str(maxi)+"_"+model+"_"+str(cap_cob)+"_"+str(p)+"_"+str(instancia)+".json", "w") as f:
   json.dump(data, f, indent=2)
