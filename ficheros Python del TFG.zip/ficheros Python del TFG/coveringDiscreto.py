import sys
import os
import gurobipy as gp
from gurobipy import GRB
import numpy as np
import time
import json
from scipy.sparse import coo_matrix
import pandas as pd
from openpyxl import load_workbook




def ifnull(pos, val):
    l = len(sys.argv)
    if len(sys.argv) <= 1 or (sys.argv[pos] == None):
        return val
    return sys.argv[pos]



## Para leer desde batería algunos datos de entrada##
dataname1=ifnull(1,"data_scp/data_20_SCP_0.2_20_1.json")




output=ifnull(2,"results/resultados_cov.xlsx")




dataname= dataname1[9:-5]
#output2='results/results_'+dataname+'.txt'


output2=ifnull(3,"results/results_"+dataname+".txt")

#print(dataname+'.json')

try:
    with open(dataname1, 'r') as f:
        data = json.load(f)
except json.JSONDecodeError as e:
    print("JSON Error:", e)

tsol1=time.time()

modelo=data["model"]
maxi= data["maxi"]
rad= data["rad"]
cap_cob=data["cap_cob"]
#per=data["per"]
maxj=maxi
p = data["p"]
I=list(range(maxi))
J=list(range(maxj))
K = np.array(data["K"], dtype=int)
f = np.array(data["f"], dtype=float)
e = np.array(data["e"], dtype=float)
b = np.array(data["b"], dtype=float)
AA = np.array(data["cover"], dtype=float)
g = np.array(data["g"], dtype=float)
#print(len(g))



A = {(int(r), int(c)): v for r, c, v in AA}

timelim=3600

t0=time.time()
# Crear modelo
model = gp.Model("Cov")

model.setParam('TimeLimit', timelim)

# Variables enteras: y[i] = número de instalaciones que se construyen en la ubicación i
y = model.addVars(I, vtype=GRB.INTEGER, name="y")

# Variables binarias: w[j,k] = número de instalaciones extra que cubren al cliente j
w = model.addVars(J,K, vtype=GRB.BINARY, name="w")

# Función objetivo: minimizar el costo total
model.setObjective(gp.quicksum(f[i]*y[i] for i in I)+
                       gp.quicksum(g[j,k]*w[j,k] for j in J for k in K), GRB.MINIMIZE)

# Restricción sobre el número de instalaciones que serán ubicadas
model.addConstr(
    gp.quicksum(y[i] for i in I) <= p,
    name=f"pInstalations"
)

# Restricciones: cada cliente j debe estar cubierto por al menos b_j instalaciones


model.addConstrs(
    (gp.quicksum(y[i] for i in I if (i, j) in A and A[i, j] > 0.5)
     == b[j] + gp.quicksum(w[j, k] for k in K)
     for j in J),
    name="cover_"
)


 
# Restricciones: cota superior del número de instalciones localizadas en ubicación i

model.addConstrs(
    (y[i] <= e[i] for i in I),
    name=f"maxRedun_"
    )

if modelo=="PPAC":
    for j in J:
        for k in range(len(K)-1):
            model.addConstr(w[j,k]>=w[j,k+1],
            name=f"worder")
        

# Resolver
#model.write("model_n.lp") 
t1=time.time()

model.optimize()
tsol2=time.time()
stime=tsol2-tsol1
mip_gap = model.MIPGap
obj=model.ObjVal

ysol=np.zeros(maxi)

for i in I: 
    ysol[i]=y[i].X

cost=sum(ysol[i]*f[i] for i in I)

#Cubierto por al menos bj+1
cover11=0
for j in J:
    print(j," ",0," ",w[j,0].X)
    if w[j,0].X>0.5:
        cover11+=1

#Cubierto por al menos bj+2
cover22=0
for j in J:
    if w[j,1].X>0.5:
        cover22+=1

#Cubierto por al menos bj+3        
cover33=0  
for j in J:
    if w[j,2].X>0.5:
        cover33+=1

#Cubierto por al menos bj+4       
cover44=0 
for j in J:
    if w[j,3].X>0.5:
        cover44+=1
      
        


cubierto=0
for j in J:
    aux=0
    for i in I:
        if ysol[i]>0.5 and (i,j) in A and A[i,j]>0.5:
            #print(j," ",i)
            aux+=1
    if aux>0: cubierto+=1



benef=sum(g[j,k]*w[j,k].X for j in J for k in K)

openfac=0
if model.status == GRB.OPTIMAL:
    f1 = open(output2, "a")
    for i in I:
        if y[i].X > 0:
            f1.write(f"{i} {y[i].X}\n")
            openfac+=y[i].X
    f1.close()
    
                                
else:
    f1 = open(output2, "a")
    f1.write(f"No se encontró solución óptima.\n")
    f1.close()

arr=[]
if(os.path.isfile(output)==False):
    df = pd.DataFrame(arr, columns=['Datos', 'Model', 'instalaciones','clientes','p','obj','tiempo','gap','status','coste','beneficio','cubierto','cubiertos1extra','cubiertos2extra','cover3','cover4','rad','%rad','time_carga','dif_open_fac'])
    df.to_excel(output, index=False)
    
 
info=[dataname1, modelo,maxi,maxj,p,obj,round(stime,4),mip_gap,model.status,cost,benef,cubierto,cover11,cover22,cover33,cover44,rad,cap_cob,t1-t0,openfac]

wb = load_workbook(output)
ws = wb['Sheet1']

# Append new row
ws.append(info)

# Save the workbook
wb.save(output)


