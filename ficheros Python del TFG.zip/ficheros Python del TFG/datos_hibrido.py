# -*- coding: utf-8 -*-
"""
Created on Mon Oct 27 12:35:41 2025

@author: orel08
"""

import random
import math
import json
import matplotlib.pyplot as plt
import sys
import numpy as np



def ifnull(pos, val):
    l = len(sys.argv)
    if len(sys.argv) <= 1 or (sys.argv[pos] == None):
        return val
    return sys.argv[pos]

#N = np.array([20,50,80,100,200,500,1000])
#p1=np.array([1,3,4,5,10,25,50]) # El número de instalaciones discretas es el 5% de N
#p2=np.array([1,3,4,5,10,25,50]) # El número de instalaciones continuas es el 5% de N
#rho = {0: 0.2, 1: 0.2} # El radio de cobertura es el 20% de la distancia media

N = np.array([50	,50,50,50,50	,50,50,50,50,50,80,80,80	,80,80,80,80	,80,80,80,100,200])
p1=np.array([0,6	,9,12,15,3,3,3,3,3,0,6,9,12,15,3,3,3,3,3,3,3]) # El número de instalaciones discretas es el 5% de N
p2=np.array([3,3,3,3,3,0,6,9,12,15,3,3,3,3,3,0,6,9,12,15,3,3]) # El número de instalaciones continuas es el 5% de N
rho = {0: 0.2, 1: 0.2} # El radio de cobertura es el 20% de la distancia media

#Número de instancias de cada tipo
ninst=5
#Numero de diferentes combinaciones
comb=22




for k in range(comb):
    for rep in range(ninst):
        random.seed(rep*10)
        #Generamos puntos en el círculo de radio 100 2DIMENSIONES
        a = []
        for j in range(N[k]):
            r = 100 * math.sqrt(random.random()) #radio <=1
            theta = random.uniform(0, 2 * math.pi)  # Ángulo
            x = round(r * math.cos(theta),4)
            y = round(r * math.sin(theta),4)
            a.append([x,y])
        
        
        #Distancias entre los puntos  
        distances = [[
            round(float(np.sqrt(sum((a[j][r] - a[i][r])**2 for r in range(2)))),4)
                for i in range(N[k])]
        for j in range(N[k])]
    
        #Distancia media entre puntos
        distm=round(np.mean(distances),4)
    
        c_ = np.ones(N[k]) # Beneficios de cobertura
        c = c_.tolist()
        #print(c)
    
        data={
            "semilla":rep*10+rep,
            "N":int(N[k]),
            "p1":int(p1[k]),
            "p2":int(p2[k]),
            "rho":rho,
            "distm":distm,
            "cov":round(0.2*distm,2),
            "a":a,
            "distances":distances,
            "c":c
            }
        # Export to JSON
        with open("datos_hibrido/data_"+str(N[k])+"_"+str(p1[k])+"_"+str(p2[k])+"_inst"+str(rep+1)+".json", "w") as f:
               json.dump(data, f, indent=2)