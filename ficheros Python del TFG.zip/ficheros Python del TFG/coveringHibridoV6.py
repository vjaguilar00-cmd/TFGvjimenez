import gurobipy as gp
from gurobipy import GRB
import numpy as np
import time
import matplotlib.pyplot as plt
from tabulate import tabulate
import random
import sys
import os
import json
import matplotlib.pyplot as plt
import sys
import numpy as np
import pandas as pd
from openpyxl import load_workbook



def ifnull(pos, val):
    l = len(sys.argv)
    if len(sys.argv) <= 1 or (sys.argv[pos] == None):
        return val
    return sys.argv[pos]

dataname1=ifnull(1,"datos_hibrido2/data_10_5_7_inst1.json")

dataname= dataname1[15:-5]

#output=ifnull(2,"results/resultados_hibrido.xlsx")
output="results/resultados_hibrido4.xlsx"

#output2=ifnull(3,"results/results_"+dataname+".txt")
output2="results/results_"+dataname+".txt"

try:
    with open(dataname1, 'r') as f:
        data = json.load(f)
except json.JSONDecodeError as e:
    print("JSON Error:", e)


# Datos de entrada
N = data["N"]
p1= data["p1"]
p2= data["p2"]
rho=data["rho"]
distm=data["distm"]
cov=data["cov"]
a=data["a"]
distances=data["distances"]
c=data["c"]





#Consideramos que sólo hay un tipo de instalación continua y un tipo de instalación discreta
# índices para tipos de instalaciones discretas
T1 = [0]
# índices para tipos de instalaciones continuas
T2 = [0] 

# índices de las p_2 instalaciones continuas del tipo 2
K2=set(range(0, p2))
# Crea el conjunto J de índices del 1 al N
J = set(range(0, N))

#Valor de U:
    
#Distancia media entre puntos
U = round(np.max(distances)**2,4)
print(U)



# Crea el conjunto que indexa las dimensiones espaciales donde se ubican los clientes 
# En nuestro caso, trabajaremos en el plano                    
DIM = set(range(0, 2))


# Crear modelo
start_time = time.time() #guardamos el tiempo
model = gp.Model("Modelo_hibrido")
#model.setParam('OutputFlag', 0)
model.setParam('TimeLimit', 3600)

# Variables binarias: y[i,t] = 1 si se selecciona la ubicación i para localizar
# una instalación discreta del tipo t
y = model.addVars(J,T1, vtype=GRB.BINARY, name="y_")

# Variables binarias: x[j,t] que vale 1 si el cliente j es cubierto por alguna instalación
# discreta del tipo t
x = model.addVars(J,T1, vtype=GRB.BINARY, name="x")

# Variables X[r,k,t] = componente r-ésima de la k-ésima instalación continua del tipo t
X = model.addVars(DIM,K2,T2, vtype=GRB.CONTINUOUS,lb=-100,ub=100,name="X")

# Variables binarias: z[j,k,t] que vale 1 si el cliente j es cubierto por alguna instalación
# continua del tipo t
z = model.addVars(J,K2,T2, vtype=GRB.BINARY, name="z")
 
#Variables auxiliares v
v = model.addVars(J,K2,DIM,T2, vtype=GRB.CONTINUOUS,lb=0, name="v")
 
#Variables auxiliares s
s = model.addVars(J,K2,T2, vtype=GRB.CONTINUOUS, lb=0, name="s")
###


# Función objetivo: maximizar la demanda total cubierta
model.setObjective(gp.quicksum(c[j]*x[j,t] for j in J for t in T1)+
                   gp.quicksum(c[j]*z[j,k,t] for j in J for k in K2 for t in T2), GRB.MAXIMIZE)
                    

# Restricción sobre el número de instalaciones que serán ubicadas
for t in T1:
    model.addConstr(
    gp.quicksum(y[i,t] for i in J) == p1,
    name=f"pInstalations_{t}"
)

# Restricciones: cada cliente j puede estar cubierto por una instalación discreta a lo sumo
for j in J:
    for t in T1:
        model.addConstr(
            x[j,t]<=gp.quicksum(y[i,t] for i in J if distances[j][i]-cov<=0),
        name=f"discretecover_{j,t}"
        )
  # Restricciones: cada cliente j debe estar cubierto por una instalación discreta o continua a lo sumo
for j in J:
      model.addConstr(
          gp.quicksum(x[j,tt] for tt in T1)+
          gp.quicksum(z[j,k,tt] for tt in T2 for k in K2) <= 1,
          name=f"discretecontinuouscover_{j}"
      )

 
# #Restricciones: cada cliente j cubierto por instalación continua debe estar dentro del radio de cobertura
# #en el caso euclídeo


for t in T2:
    for i in J:
        for k in K2:
            for l in DIM:
                model.addConstr(
                v[i,k,l,t]>=a[i][l]-X[l,k,t],
                name=f"rest10_{i,k,l,t}")
for t in T2:
    for i in J:
        for k in K2:
            for l in DIM:
                model.addConstr(
                v[i,k,l,t]>=-a[i][l]+X[l,k,t],
                name=f"rest11_{i,k,l,t}")
                
for t in T2:
    for i in J:
        for k in K2:
                model.addConstr(
                s[i,k,t]>=gp.quicksum(v[i,k,l,t]**2 for l in DIM),
                name=f"rest12_{i,k,t}")
 
print(U)
print(cov) 
covcuad=round(cov**2,2)   
for t in T2:
    for i in J:
        for k in K2:
                model.addConstr(
                s[i,k,t]<=covcuad+U*(1-z[i,k,t]),
                name=f"rest13_{i,k,t}")

#model.write("modelo.lp")
print("comienzo resolucion")
model.optimize()
print(model.status)
end_time = time.time()
stime=end_time-start_time
obj=model.ObjVal
status=model.status
print(model.ObjVal)

mip_gap = model.MIPGap 

ysol=[[y[i,t].X for i in J] for t in T1]



openfac=0
x0=[]
x1=[]
if model.status == GRB.OPTIMAL:
    f1 = open(output2, "a")
    for i in J:
        for t in T1:
            if y[i,t].X > 0:
                f1.write(f"{i} {y[i,t].X}\n")
                x0.append(a[i][0])
                x1.append(a[i][1])
                openfac+=y[i,t].X
    for t in T2:
        for k in K2:
            f1.write(f"{i} {X[0,k,t].X} {X[1,k,t].X}\n")
            x0.append(X[0,k,t].X)
            x1.append(X[1,k,t].X)
    f1.close()                            
else:
    f1 = open(output2, "a")
    f1.write(f"No se encontró solución óptima.\n")
    f1.close()


coord0=[]
coord1=[]
for i in J:
    coord0.append(a[i][0])
    coord1.append(a[i][1])
plt.scatter(coord0,coord1, color='blue', label='Datos base')
plt.scatter(x0,x1, color='red')

radio = cov
for (xc, yc) in zip(x0, x1):
    circulo = plt.Circle((xc, yc), radio, color='red', alpha=0.3, zorder=2)
    plt.gca().add_patch(circulo)
plt.axis('equal')
plt.legend()
plt.title('Scatterplot con círculos centrados en instalaciones')
#plt.show()
plt.savefig('figuras/figura'+dataname+'.pdf')

arr=[]
if(os.path.isfile(output)==False):
    df = pd.DataFrame(arr, columns=['Datos', 'Model', 'instalaciones','clientes','p1','p2','status','time','Obj','porc_cub',"Gap"])
    df.to_excel(output, index=False)


porc_cubierto=obj/N*100
print(porc_cubierto)
#df = pd.DataFrame(arr, columns=[dataname, 'COV',maxi,maxj,p,obj,round(stime,4),mip_gap,cost,benef,cover1,cover2])
info=[dataname1,"Hibrido",N,N,p1,p2,status,round(stime,4),obj,porc_cubierto,mip_gap]

wb = load_workbook(output)
ws = wb['Sheet1']

# Append new row
ws.append(info)

# Save the workbook
wb.save(output)

